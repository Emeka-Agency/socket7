https://github.com/O-clock-II?q=ch&type=&language=
https://github.com/O-clock-II/chatroom-server/blob/master/server.js
https://github.com/O-clock-II/chatroom-v1-tonytiratayoclock/tree/master/src

test same time only one user modify
Waiting list (object / array)
    - test toggle / check once at a time
    - test add column
    - test add field